create definer = root@localhost event `[Quest] Daily Quest Reset` on schedule
    every '1' DAY
        starts '2020-08-26 00:00:00'
        ends '2025-10-10 19:34:15'
    enable
    do
    UPDATE users SET DailyQuests0 = 0, DailyQuests1 = 0, DailyQuests2 = 0, UpgradeDays=UpgradeDays-1;

