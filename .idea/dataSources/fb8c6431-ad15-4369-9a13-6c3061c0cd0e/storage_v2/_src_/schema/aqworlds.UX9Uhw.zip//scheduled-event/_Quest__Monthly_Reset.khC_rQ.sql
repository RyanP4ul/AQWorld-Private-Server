create definer = root@localhost event `[Quest] Monthly Reset` on schedule
    every '1' MONTH
        starts '2020-10-10 19:33:00'
        ends '2025-10-10 19:34:15'
    enable
    do
    UPDATE users SET MonthlyQuests0 = 0;

